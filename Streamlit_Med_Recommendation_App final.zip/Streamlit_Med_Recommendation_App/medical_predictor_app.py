# medical_predictor_app.py

import streamlit as st
import pandas as pd
from disease_predictor import SymptomChecker

# Load additional data
description_df = pd.read_csv("description.csv")
precautions_df = pd.read_csv("precautions_df.csv")
medications_df = pd.read_csv("medications.csv")
diets_df = pd.read_csv("diets.csv")
workout_df = pd.read_csv("workout_df.csv")

# Initialize the model
checker = SymptomChecker()
checker.prepare_data('Training.csv')

st.title("AI-based Health Diagnosis Assistant")
st.write("Please select symptoms below to get a possible diagnosis.")

symptoms = checker.get_all_symptoms()
selected = st.multiselect("Choose your symptoms:", options=symptoms)

if st.button("Diagnose"):
    if selected:
        disease = checker.predict(selected)
        st.success(f"The predicted condition based on the given symptoms is {disease}.")

        # Show Description
        desc_row = description_df[description_df['Disease'].str.lower() == disease.lower()]
        if not desc_row.empty:
            st.markdown("### 📝 Disease Summary")
            st.write(desc_row.iloc[0]['Description'])

        # Show Precautions
        pre_row = precautions_df[precautions_df['Disease'].str.lower() == disease.lower()]
        if not pre_row.empty:
            st.markdown("### ⚠️ Precautionary Measures")
            st.write("- " + "\n- ".join(pre_row.iloc[0][1:].dropna()))

        # Show Medications
        med_row = medications_df[medications_df['Disease'].str.lower() == disease.lower()]
        if not med_row.empty:
            st.markdown("### 💊 Recommended Medications")
            st.write(med_row.iloc[0]['Medication'])

        # Show Diet
        diet_row = diets_df[diets_df['Disease'].str.lower() == disease.lower()]
        if not diet_row.empty:
            st.markdown("### 🥗 Suggested Diet")
            st.write(diet_row.iloc[0]['Diet'])

        # Show Workout
        workout_row = workout_df[workout_df['disease'].str.lower() == disease.lower()]
        if not workout_row.empty:
            st.markdown("### 🏃 Recommended Workouts")
            st.write(workout_row.iloc[0]['workout'])

    else:
        st.warning("Please select at least one symptom before proceeding.")

