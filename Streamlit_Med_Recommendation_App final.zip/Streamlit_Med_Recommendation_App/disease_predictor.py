# disease_predictor.py

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import ExtraTreesClassifier

class SymptomChecker:
    def __init__(self):
        self.model = None
        self.label_encoder = None
        self.symptom_list = None

    def prepare_data(self, filepath):
        data = pd.read_csv(filepath)
        self.symptom_list = data.columns[:-1].tolist()
        labels = data['prognosis']
        self.label_encoder = LabelEncoder()
        encoded_labels = self.label_encoder.fit_transform(labels)

        X = data.drop('prognosis', axis=1)
        y = encoded_labels

        self.train_model(X, y)
        return X, y

    def train_model(self, X, y):
        classifier = ExtraTreesClassifier()
        classifier.fit(X, y)
        self.model = classifier

    def predict(self, symptoms):
        input_vector = np.zeros(len(self.symptom_list))
        for symptom in symptoms:
            if symptom in self.symptom_list:
                index = self.symptom_list.index(symptom)
                input_vector[index] = 1
        prediction = self.model.predict([input_vector])[0]
        return self.label_encoder.inverse_transform([prediction])[0]

    def get_all_symptoms(self):
        return self.symptom_list

